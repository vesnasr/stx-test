export default [
    { 'id' : 1, 'name': 'Contact B1' },
    { 'id' : 2, 'name': 'Contact B2' }
]