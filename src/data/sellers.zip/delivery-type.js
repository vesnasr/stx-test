export default [
    { 'id' : 1, 'name': 'Delivery A' },
    { 'id' : 2, 'name': 'Delivery B' },
    { 'id' : 3, 'name': 'Delivery C' },
    { 'id' : 4, 'name': 'Delivery D' }
]