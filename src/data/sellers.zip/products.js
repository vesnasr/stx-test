export default [
    { 'id' : 1, 'name': 'Product A' },
    { 'id' : 2, 'name': 'Product B' },
    { 'id' : 3, 'name': 'Product C' }
]