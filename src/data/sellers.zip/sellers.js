export default [
    { 'id' : 1, 'name': 'Seller A' },
    { 'id' : 2, 'name': 'Seller B' },
    { 'id' : 3, 'name': 'Seller C' }
]