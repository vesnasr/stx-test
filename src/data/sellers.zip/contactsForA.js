export default [
    { 'id' : 1, 'name': 'Contact A1' },
    { 'id' : 2, 'name': 'Contact A2' }
]