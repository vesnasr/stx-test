export default [
    { 'id' : 1, 'name': 'Client A' },
    { 'id' : 2, 'name': 'Client B' }
]